﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float speed;

    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Debug.Log("Player Dead!!");
            other.gameObject.GetComponent<Player>().isDead = true;
        }
        if (other.tag == "PlayerProjectile")
        {
            Kill();
        }
    }

    public void Kill()
    {
        // do a bunch of other stuff
        Destroy(gameObject);
    }
}
