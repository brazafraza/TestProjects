﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmartBomb : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            GameObject[] allEnemies = GameObject.FindGameObjectsWithTag("Enemy");

            for (int i = 0; i < allEnemies.Length; i++)
            {
                allEnemies[i].GetComponent<Enemy>().Kill();
            }

            Destroy(gameObject);
        }

    }
}
