﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmartBomb : MonoBehaviour
{
    // NEW
    public Color RegularColor;
    public Color HighlightColor;

    public float colorChangeSpeed;

    private Renderer r;
    private bool isChangingColor;
    private float lerpAmount;

    void Start()
    {
        r = GetComponent<Renderer>();
        r.material.color = RegularColor;
        isChangingColor = false;
        lerpAmount = 0.0f;
    }

    void Update()
    {
        if (isChangingColor)
        {
            ContinueChangeColor(lerpAmount);

            lerpAmount += colorChangeSpeed * Time.deltaTime;
            if (lerpAmount >= 1.0f)
            {
                lerpAmount = 0.0f;
                isChangingColor = false;
            }
        }
    }
    // NEW

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            GameObject[] allEnemies = GameObject.FindGameObjectsWithTag("Enemy");

            for (int i = 0; i < allEnemies.Length; i++)
            {
                allEnemies[i].GetComponent<Enemy>().Kill();
            }

            Destroy(gameObject);
        }

    }

    // NEW
    public void StartChangeColor()
    {
        r.material.color = HighlightColor;
        isChangingColor = true;
    }

    public void ContinueChangeColor(float percent)
    {
        r.material.color = Color.Lerp(HighlightColor, RegularColor, percent);
    }
    // NEW
}
