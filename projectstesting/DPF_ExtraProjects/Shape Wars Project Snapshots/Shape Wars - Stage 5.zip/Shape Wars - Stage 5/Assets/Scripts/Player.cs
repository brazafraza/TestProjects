﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float rotateSpeed;
    public float moveSpeed;

    public bool isDead;

    private void Start()
    {
        isDead = false;
    }

    void Update()
    {
        if (!isDead)
        {
            if ((Input.GetKey(KeyCode.D)) || (Input.GetKey(KeyCode.RightArrow)))
            {
                transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime);
            }
            if ((Input.GetKey(KeyCode.A)) || (Input.GetKey(KeyCode.LeftArrow)))
            {
                transform.Rotate(Vector3.up * rotateSpeed * -1 * Time.deltaTime);
            }
            if ((Input.GetKey(KeyCode.W)) || (Input.GetKey(KeyCode.UpArrow)))
            {
                transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
            }
            if ((Input.GetKey(KeyCode.S)) || (Input.GetKey(KeyCode.DownArrow)))
            {
                transform.Translate(Vector3.forward * moveSpeed * -0.25f * Time.deltaTime);
            }

            // NEW
            DetectPickUp();
            // NEW
        }
    }

    // NEW
    void DetectPickUp()
    {
        RaycastHit hitInfo;
        float rayLength = 8.0f;

        Debug.DrawRay(transform.position, transform.forward * rayLength, Color.red);

        if (Physics.Raycast(transform.position, transform.forward, out hitInfo, rayLength))
        {
            if (hitInfo.collider.gameObject.tag == "PickUp")
            {
                Debug.Log("Pick Up Detected!!");
                hitInfo.collider.gameObject.GetComponent<SmartBomb>().StartChangeColor();
            }
        }
    }
    // NEW
}
