﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmartBomb : MonoBehaviour
{
    public Color RegularColor;
    public Color HighlightColor;

    public float colorChangeSpeed;

    private Renderer r;
    private bool isChangingColor;
    private float lerpAmount;

    void Start()
    {
        r = GetComponent<Renderer>();
        r.material.color = RegularColor;
        isChangingColor = false;
        lerpAmount = 0.0f;
    }

    void Update()
    {
        if (isChangingColor)
        {
            ContinueChangeColor(lerpAmount);

            lerpAmount += colorChangeSpeed * Time.deltaTime;
            if (lerpAmount >= 1.0f)
            {
                lerpAmount = 0.0f;
                isChangingColor = false;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            GameObject[] allEnemies = GameObject.FindGameObjectsWithTag("Enemy");
            for (int i = 0; i < allEnemies.Length; i++)
                allEnemies[i].GetComponent<Enemy>().Kill();

            GameObject[] allHomingEnemies = GameObject.FindGameObjectsWithTag("HomingEnemy");
            for (int i = 0; i < allHomingEnemies.Length; i++)
                allHomingEnemies[i].GetComponent<EnemyHoming>().Kill();

            Destroy(gameObject);
        }

    }

    public void StartChangeColor()
    {
        r.material.color = HighlightColor;
        isChangingColor = true;
    }

    public void ContinueChangeColor(float percent)
    {
        r.material.color = Color.Lerp(HighlightColor, RegularColor, percent);
    }
}
