﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XboxCtrlrInput;

public class Player : MonoBehaviour
{
    public float rotateSpeed;
    public float moveSpeed;

    public bool isDead;

    public XboxController controller;

    private void Start()
    {
        isDead = false;
    }

    void Update()
    {
        if (!isDead)
        {
            MoveAndRotatePlayer();
            DetectPickUp();
        }
    }

    void MoveAndRotatePlayer()
    {
        // Legacy keyboard input // will unfortunately apply additively with controller input
        if ((Input.GetKey(KeyCode.D)) || (Input.GetKey(KeyCode.RightArrow)))
        {
            transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.A)) || (Input.GetKey(KeyCode.LeftArrow)))
        {
            transform.Rotate(Vector3.up * rotateSpeed * -1 * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.W)) || (Input.GetKey(KeyCode.UpArrow)))
        {
            transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.S)) || (Input.GetKey(KeyCode.DownArrow)))
        {
            transform.Translate(Vector3.forward * moveSpeed * -0.25f * Time.deltaTime);
        }
        ////////////////////////

        float moveAxisX = XCI.GetAxis(XboxAxis.LeftStickX, controller);
        float moveAxisY = XCI.GetAxis(XboxAxis.LeftStickY, controller);

        float rotAxisX = XCI.GetAxis(XboxAxis.RightStickX, controller);
        float rotAxisY = XCI.GetAxis(XboxAxis.RightStickY, controller);

        Vector3 movement = new Vector3(moveAxisX, 0.0f, moveAxisY);
        Vector3 direction = new Vector3(rotAxisX, 0.0f, rotAxisY);

        transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);
        transform.LookAt(transform.position + direction);
    }

    void DetectPickUp()
    {
        RaycastHit hitInfo;
        float rayLength = 8.0f;

        Debug.DrawRay(transform.position, transform.forward * rayLength, Color.red);

        if (Physics.Raycast(transform.position, transform.forward, out hitInfo, rayLength))
        {
            if (hitInfo.collider.gameObject.tag == "PickUp")
            {
                Debug.Log("Pick Up Detected!!");
                hitInfo.collider.gameObject.GetComponent<SmartBomb>().StartChangeColor();
            }
        }
    }
}
