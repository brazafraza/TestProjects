﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using XboxCtrlrInput;

public class Player : MonoBehaviour
{
    public float rotateSpeed;
    public float moveSpeed;
    public float moveCheckRayLength = 0.5f;

    public float bounceDistance;

    public bool isDead;

    public XboxController controller;

    private void Start()
    {
        isDead = false;
    }

    void Update()
    {
        if (!isDead)
        {
            MoveAndRotatePlayer();
            DetectPickUp();
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("Hi!!");
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    void MoveAndRotatePlayer()
    {
        // Legacy keyboard input // will unfortunately apply additively with controller input
        if ((Input.GetKey(KeyCode.D)) || (Input.GetKey(KeyCode.RightArrow)))
        {
            transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.A)) || (Input.GetKey(KeyCode.LeftArrow)))
        {
            transform.Rotate(Vector3.up * rotateSpeed * -1 * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.W)) || (Input.GetKey(KeyCode.UpArrow)))
        {
            transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
        }
        if ((Input.GetKey(KeyCode.S)) || (Input.GetKey(KeyCode.DownArrow)))
        {
            transform.Translate(Vector3.forward * moveSpeed * -0.25f * Time.deltaTime);
        }
        ////////////////////////

        float moveAxisX = XCI.GetAxis(XboxAxis.LeftStickX, controller);
        float moveAxisY = XCI.GetAxis(XboxAxis.LeftStickY, controller);

        float rotAxisX = XCI.GetAxis(XboxAxis.RightStickX, controller);
        float rotAxisY = XCI.GetAxis(XboxAxis.RightStickY, controller);

        Vector3 movement = new Vector3(moveAxisX, 0.0f, moveAxisY);
        Vector3 direction = new Vector3(rotAxisX, 0.0f, rotAxisY);

        if (CheckMovement(movement))
            transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);
        else
            transform.Translate(-movement * bounceDistance, Space.World);
        transform.LookAt(transform.position + direction);
    }

    bool CheckMovement(Vector3 movementDirection)
    {
        bool noCollisions = true;

        RaycastHit moveCheckFL;
        RaycastHit moveCheckFR;
        RaycastHit moveCheckRF;
        RaycastHit moveCheckRB;
        RaycastHit moveCheckBL;
        RaycastHit moveCheckBR;
        RaycastHit moveCheckLF;
        RaycastHit moveCheckLB;

        Vector3 moveCheckFLStartPos = new Vector3(0.5f, 0.0f, 0.5f);
        Vector3 moveCheckFRStartPos = new Vector3(-0.5f, 0.0f, 0.5f);
        Vector3 moveCheckRFStartPos = new Vector3(0.5f, 0.0f, 0.5f);
        Vector3 moveCheckRBStartPos = new Vector3(0.5f, 0.0f, -0.5f);
        Vector3 moveCheckBLStartPos = new Vector3(0.5f, 0.0f, -0.5f);
        Vector3 moveCheckBRStartPos = new Vector3(-0.5f, 0.0f, -0.5f);
        Vector3 moveCheckLFStartPos = new Vector3(-0.5f, 0.0f, 0.5f);
        Vector3 moveCheckLBStartPos = new Vector3(-0.5f, 0.0f, -0.5f);

        Ray rayFL = new Ray(transform.position + transform.forward * 0.5f + transform.right * 0.5f, transform.forward * moveCheckRayLength);
        Ray rayFR = new Ray(transform.position + transform.forward * -0.5f + transform.right * 0.5f, transform.forward * -moveCheckRayLength);
        Ray rayRF = new Ray(transform.position + transform.forward * 0.5f + transform.right * 0.5f, transform.right * moveCheckRayLength);
        Ray rayRB = new Ray(transform.position + transform.forward * 0.5f + transform.right * -0.5f, transform.right * -moveCheckRayLength);
        Ray rayBL = new Ray(transform.position + transform.forward * 0.5f + transform.right * -0.5f, transform.forward * moveCheckRayLength);
        Ray rayBR = new Ray(transform.position + transform.forward * -0.5f + transform.right * -0.5f, transform.forward * -moveCheckRayLength);
        Ray rayLF = new Ray(transform.position + transform.forward * -0.5f + transform.right * 0.5f, transform.right * moveCheckRayLength);
        Ray rayLB = new Ray(transform.position + transform.forward * -0.5f + transform.right * -0.5f, transform.right * -moveCheckRayLength);

        {
            Debug.DrawRay(rayFL.GetPoint(0), rayFL.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayFR.GetPoint(0), rayFR.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayRF.GetPoint(0), rayRF.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayRB.GetPoint(0), rayRB.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayBL.GetPoint(0), rayBL.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayBR.GetPoint(0), rayBR.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayLF.GetPoint(0), rayLF.direction * moveCheckRayLength, Color.green);
            Debug.DrawRay(rayLB.GetPoint(0), rayLB.direction * moveCheckRayLength, Color.green);
        }

        if (Physics.Raycast(rayFL, out moveCheckFL, moveCheckRayLength))
            if (moveCheckFL.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if (Physics.Raycast(rayFR, out moveCheckFR, moveCheckRayLength))
            if (moveCheckFR.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayRF, out moveCheckRF, moveCheckRayLength))
            if (moveCheckRF.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayRB, out moveCheckRB, moveCheckRayLength))
            if (moveCheckRB.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayBL, out moveCheckBL, moveCheckRayLength))
            if (moveCheckBL.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayBR, out moveCheckBR, moveCheckRayLength))
            if (moveCheckBR.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayLF, out moveCheckLF, moveCheckRayLength))
            if (moveCheckLF.collider.gameObject.tag == "Wall")
                noCollisions = false;

        if(Physics.Raycast(rayLB, out moveCheckLB, moveCheckRayLength))
            if (moveCheckLB.collider.gameObject.tag == "Wall")
                noCollisions = false;

        return noCollisions;
    }

    void DetectPickUp()
    {
        RaycastHit hitInfo;
        float rayLength = 8.0f;

        Debug.DrawRay(transform.position, transform.forward * rayLength, Color.red);

        if (Physics.Raycast(transform.position, transform.forward, out hitInfo, rayLength))
        {
            if (hitInfo.collider.gameObject.tag == "PickUp")
            {
                Debug.Log("Pick Up Detected!!");
                hitInfo.collider.gameObject.GetComponent<SmartBomb>().StartChangeColor();
            }
        }
    }
}
